import json
from flask import Flask, request, render_template, redirect, flash, url_for,Blueprint
from flask_jwt import JWT, jwt_required, current_identity
from sqlalchemy.exc import IntegrityError
from datetime import timedelta

from models import db, Pillows


def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sqlite.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
    app.config['SECRET_KEY'] = "MYSECRET"
    app.config['JWT_EXPIRATION_DELTA'] = timedelta(days=7)
    db.init_app(app)
    return app


app = create_app()
app.app_context().push()
# db.create_all(app=app)



@app.route('/')  #startpage
def register():
    check = request.args.get('query')#matches the name variable in the index.html    
    if check:
        posts= Pillows.query.filter(Pillows.Name.contains(check))
    else:
        posts = Pillows.query.all() #posts = Pillows.query.limit(3).all() for first 3 data
    return render_template('index.html', database = posts) #can only use this with render

@app.route('/index.html')#make sure the href matches with this route
#@jwt_required()
def main():
    return register()

@app.route('/Contact.html') 
def contactPage():
    return app.send_static_file('Contact.html')



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
