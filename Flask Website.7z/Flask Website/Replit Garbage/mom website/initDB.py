from app import db, Ingredient, app

db.create_all(app=app)

ingredients = ["pinkpillow","bluepillow","candypillow","circlepillow"]

for ingredient in ingredients:
    ingredient=Ingredient(name=ingredient)
    db.session.add(ingredient)
    db.session.commit()

print('database initialized!')