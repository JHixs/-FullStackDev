import json
from flask import Flask, request, render_template, redirect, flash, url_for
from flask_jwt import JWT, jwt_required, current_identity
from sqlalchemy.exc import IntegrityError
from datetime import timedelta

from models import db, Pillows


def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sqlite.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
    app.config['SECRET_KEY'] = "MYSECRET"
    app.config['JWT_EXPIRATION_DELTA'] = timedelta(days=7)
    db.init_app(app)
    return app


app = create_app()
app.app_context().push()
# db.create_all(app=app)


@app.route('/')  #startpage
def register():
    return app.send_static_file('Contact.html')


@app.route('/index.html')#make sure the href matches with this route
#@jwt_required()
def main():
    return app.send_static_file('index.html')

@app.route('/Contact.html') 
def contactPage():
    return app.send_static_file('Contact.html')



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
